import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Wallet, Shield, ArrowRight, Loader2, CheckCircle2 } from 'lucide-react';

interface WalletConnectProps {
  onConnect: () => void;
}

export const WalletConnect: React.FC<WalletConnectProps> = ({ onConnect }) => {
  const [connecting, setConnecting] = useState<string | null>(null);

  const handleConnect = (walletName: string) => {
    setConnecting(walletName);
    // Simulate network delay
    setTimeout(() => {
      onConnect();
    }, 1500);
  };

  const wallets = [
    { name: 'Metamask', icon: '🦊', color: 'bg-orange-50 hover:border-orange-200' },
    { name: 'Phantom', icon: '👻', color: 'bg-purple-50 hover:border-purple-200' },
    { name: 'WalletConnect', icon: '🔗', color: 'bg-blue-50 hover:border-blue-200' }
  ];

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <div className="text-center mb-10 space-y-4">
          <div className="w-16 h-16 bg-[#1F4FFF]/10 rounded-2xl flex items-center justify-center mx-auto text-[#1F4FFF]">
            <Wallet size={32} />
          </div>
          <h2 className="text-3xl font-bold text-slate-900">Connect Wallet</h2>
          <p className="text-slate-500 text-lg">
            Connect securely to participate in verified sessions.
          </p>
        </div>

        <div className="space-y-4">
          {wallets.map((wallet) => (
            <button
              key={wallet.name}
              disabled={!!connecting}
              onClick={() => handleConnect(wallet.name)}
              className={`w-full p-4 rounded-xl border-2 border-transparent transition-all flex items-center justify-between group relative overflow-hidden ${
                connecting === wallet.name 
                  ? 'bg-slate-50 border-slate-200 cursor-wait' 
                  : `bg-white border-slate-100 shadow-sm hover:shadow-md ${wallet.color}`
              }`}
            >
              <div className="flex items-center gap-4 relative z-10">
                <span className="text-2xl">{wallet.icon}</span>
                <span className="font-bold text-slate-700 group-hover:text-slate-900">{wallet.name}</span>
              </div>
              
              <div className="relative z-10 text-slate-300 group-hover:text-[#1F4FFF] transition-colors">
                {connecting === wallet.name ? (
                  <Loader2 className="animate-spin text-[#1F4FFF]" />
                ) : (
                   <ArrowRight size={20} />
                )}
              </div>
            </button>
          ))}
        </div>

        <div className="mt-8 flex items-center justify-center gap-2 text-xs text-slate-400 font-medium">
          <Shield size={14} />
          <span>End-to-end encrypted connection</span>
        </div>
      </motion.div>
    </div>
  );
};