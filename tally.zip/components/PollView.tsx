import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle2, Circle } from 'lucide-react';

const INITIAL_OPTIONS = [
  { id: 1, label: "React Server Components", votes: 45 },
  { id: 2, label: "Signals & Fine-grained Reactivity", votes: 32 },
  { id: 3, label: "AI-Generated UI", votes: 15 },
  { id: 4, label: "WebAssembly Mainstream", votes: 8 },
];

export const PollView: React.FC = () => {
  const [hasVoted, setHasVoted] = useState(false);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [options, setOptions] = useState(INITIAL_OPTIONS);

  const totalVotes = options.reduce((acc, curr) => acc + curr.votes, 0) + (hasVoted ? 1 : 0);

  const handleVote = (id: number) => {
    setSelectedId(id);
    // Simulate API delay
    setTimeout(() => {
      setHasVoted(true);
      setOptions(prev => prev.map(opt => 
        opt.id === id ? { ...opt, votes: opt.votes + 1 } : opt
      ));
    }, 600);
  };

  return (
    <div className="min-h-screen bg-white flex items-center justify-center p-6">
      <div className="w-full max-w-2xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-8"
        >
          {/* Header */}
          <div className="space-y-2 text-center md:text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#1F4FFF]/10 text-[#1F4FFF] text-xs font-bold uppercase tracking-wider">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#1F4FFF] opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-[#1F4FFF]"></span>
              </span>
              Live Poll
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 leading-tight">
              What is the biggest trend in frontend development for 2024?
            </h2>
          </div>

          {/* Poll Content */}
          <div className="space-y-4">
            <AnimatePresence mode='wait'>
              {!hasVoted ? (
                /* VOTING STATE */
                <motion.div
                  key="voting"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="space-y-3"
                >
                  {options.map((option) => (
                    <motion.button
                      key={option.id}
                      onClick={() => handleVote(option.id)}
                      whileHover={{ scale: 1.01, x: 4 }}
                      whileTap={{ scale: 0.99 }}
                      className={`w-full p-6 text-left rounded-2xl border-2 transition-all group flex items-center justify-between ${
                        selectedId === option.id
                          ? 'border-[#1F4FFF] bg-[#1F4FFF]/5'
                          : 'border-slate-100 bg-white hover:border-[#1F4FFF]/30 hover:shadow-lg hover:shadow-blue-500/5'
                      }`}
                    >
                      <span className={`text-lg font-medium transition-colors ${
                        selectedId === option.id ? 'text-[#1F4FFF]' : 'text-slate-700'
                      }`}>
                        {option.label}
                      </span>
                      <div className={`text-[#1F4FFF] transition-opacity ${
                        selectedId === option.id ? 'opacity-100' : 'opacity-0 group-hover:opacity-50'
                      }`}>
                        {selectedId === option.id ? <CheckCircle2 size={24} /> : <Circle size={24} />}
                      </div>
                    </motion.button>
                  ))}
                </motion.div>
              ) : (
                /* RESULTS STATE */
                <motion.div
                  key="results"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="space-y-6"
                >
                  {options.map((option, index) => {
                    const percentage = Math.round((option.votes / totalVotes) * 100);
                    const isWinner = index === 0; // Assuming sorted for visual, or just highlighting logic

                    return (
                      <div key={option.id} className="relative">
                        {/* Label Row */}
                        <div className="flex justify-between items-end mb-2 relative z-10">
                          <span className={`font-semibold ${selectedId === option.id ? 'text-[#1F4FFF]' : 'text-slate-700'}`}>
                            {option.label}
                            {selectedId === option.id && <span className="ml-2 text-xs bg-[#1F4FFF]/10 text-[#1F4FFF] px-2 py-0.5 rounded-full">You</span>}
                          </span>
                          <span className="font-bold text-slate-900">{percentage}%</span>
                        </div>

                        {/* Bar Container */}
                        <div className="h-4 w-full bg-slate-100 rounded-full overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${percentage}%` }}
                            transition={{ duration: 1, delay: index * 0.1, ease: "easeOut" }}
                            className={`h-full rounded-full ${
                              selectedId === option.id ? 'bg-[#1F4FFF]' : 'bg-slate-300'
                            }`}
                          />
                        </div>
                        
                        {/* Vote Count (Optional Detail) */}
                        <p className="text-right text-xs text-slate-400 mt-1">{option.votes} votes</p>
                      </div>
                    );
                  })}

                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 1 }}
                    className="pt-8 text-center"
                  >
                    <p className="text-slate-400 text-sm">Total votes: {totalVotes}</p>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>
    </div>
  );
};