import React from 'react';
import { motion, useMotionValue, useTransform, useSpring, useMotionTemplate } from 'framer-motion';
import { ArrowRight, Activity, ShieldCheck, Zap, Lock, Globe, Users, Cpu, BarChart3, Fingerprint } from 'lucide-react';
import { Logo } from './Logo';

interface LandingPageProps {
  onStart: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onStart }) => {
  const features = [
    {
      icon: <Fingerprint size={24} />,
      title: "Sybil Resistant",
      desc: "Wallet-based authentication ensures one person, one vote. Eliminate bots from your consensus.",
      color: "text-[#1F4FFF]",
      bg: "bg-[#1F4FFF]/10"
    },
    {
      icon: <Zap size={24} />,
      title: "Real-time Sync",
      desc: "Optimistic UI updates provide instant feedback while background workers handle chain synchronization.",
      color: "text-[#22C55E]",
      bg: "bg-[#22C55E]/10"
    },
    {
      icon: <Lock size={24} />,
      title: "Privacy Preserving",
      desc: "Optionally leverage Zero-Knowledge proofs to prove eligibility without revealing identity.",
      color: "text-purple-600",
      bg: "bg-purple-500/10"
    }
  ];

  const stats = [
    { label: "Active Sessions", value: "2,401" },
    { label: "Votes Cast", value: "1.2M+" },
    { label: "Avg Latency", value: "<50ms" }
  ];

  // Mouse tilt logic for 3D card
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  
  // Smooth spring physics for rotation
  const mouseXSpring = useSpring(x, { stiffness: 300, damping: 30 });
  const mouseYSpring = useSpring(y, { stiffness: 300, damping: 30 });

  // Map mouse position to rotation degrees (more pronounced: 25deg)
  const rotateX = useTransform(mouseYSpring, [-0.5, 0.5], ["20deg", "-20deg"]);
  const rotateY = useTransform(mouseXSpring, [-0.5, 0.5], ["-20deg", "20deg"]);

  // Dynamic glare effect based on mouse position
  const glareX = useTransform(mouseXSpring, [-0.5, 0.5], ["0%", "100%"]);
  const glareY = useTransform(mouseYSpring, [-0.5, 0.5], ["0%", "100%"]);
  const glareBackground = useMotionTemplate`radial-gradient(circle at ${glareX} ${glareY}, rgba(255,255,255,0.7) 0%, rgba(255,255,255,0) 80%)`;

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    
    // Calculate percentage from center (-0.5 to 0.5)
    const xPct = (mouseX / width) - 0.5;
    const yPct = (mouseY / height) - 0.5;
    
    x.set(xPct);
    y.set(yPct);
  };

  const handleMouseLeave = () => {
    // Reset to center on leave
    x.set(0);
    y.set(0);
  };

  return (
    <div className="flex flex-col bg-white">
      {/* ---------------- HERO SECTION ---------------- */}
      <section className="min-h-screen flex flex-col justify-center relative overflow-hidden pb-20 pt-10 md:pt-0">
        {/* Decorative Background Blobs */}
        <motion.div 
          animate={{ 
            x: [0, 50, 0], 
            y: [0, 30, 0],
            scale: [1, 1.1, 1] 
          }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="absolute top-20 left-20 w-[300px] md:w-[500px] h-[300px] md:h-[500px] bg-[#1F4FFF]/5 rounded-full blur-3xl pointer-events-none" 
        />
        <motion.div 
          animate={{ 
            x: [0, -30, 0], 
            y: [0, 50, 0],
            scale: [1, 1.2, 1] 
          }}
          transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
          className="absolute bottom-20 right-20 w-[300px] md:w-[600px] h-[300px] md:h-[600px] bg-[#22C55E]/5 rounded-full blur-3xl pointer-events-none" 
        />

        <div className="container mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center relative z-10">
          
          {/* Left: Typography & CTA */}
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="space-y-6 md:space-y-8 text-center lg:text-left"
          >
            <div className="inline-flex items-center gap-3 px-5 py-2.5 rounded-2xl bg-slate-50 border border-slate-100 shadow-sm text-slate-600 text-sm font-semibold tracking-wide hover:border-blue-100 transition-colors">
              <div className="w-5 h-5 shadow-sm rounded">
                  <Logo className="w-full h-full" />
              </div>
              <span>Tally v1.0</span>
            </div>

            <h1 className="text-4xl md:text-6xl font-bold leading-[1.1] tracking-tight text-slate-900">
              You can’t trust live engagement <br className="hidden lg:block"/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#1F4FFF] to-[#22C55E]">
                you don’t control.
              </span>
            </h1>

            <p className="text-lg md:text-xl text-slate-500 max-w-lg leading-relaxed mx-auto lg:mx-0">
              Centralized platforms own the data, the rules, and the outcome.
            </p>

            <div className="flex flex-col sm:flex-row items-center gap-4 pt-4 justify-center lg:justify-start">
              <motion.button
                whileHover={{ scale: 1.02, y: -2 }}
                whileTap={{ scale: 0.98 }}
                onClick={onStart}
                className="w-full sm:w-auto px-10 py-5 bg-[#1F4FFF] text-white font-bold text-lg rounded-2xl shadow-[0_20px_40px_-12px_rgba(31,79,255,0.3)] hover:shadow-[0_20px_40px_-8px_rgba(31,79,255,0.4)] transition-all flex items-center justify-center gap-3"
              >
                Get Started <ArrowRight size={20} />
              </motion.button>
              
              <button className="px-8 py-5 text-slate-500 font-bold hover:text-[#1F4FFF] transition-colors flex items-center gap-2">
                <Globe size={20} /> View Demo
              </button>
            </div>
          </motion.div>

          {/* Right: 3D Floating Glass Card */}
          <div 
            className="relative h-[400px] md:h-[600px] flex items-center justify-center perspective-[2000px] mt-8 lg:mt-0"
            style={{ perspective: 2000 }}
            onMouseMove={handleMouseMove}
            onMouseLeave={handleMouseLeave}
          >
            <motion.div
              initial={{ opacity: 0, y: 50, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
              style={{ 
                rotateX, 
                rotateY,
                transformStyle: 'preserve-3d'
              }}
              whileHover={{ scale: 1.05 }}
              className="w-full max-w-md bg-white/60 backdrop-blur-xl border border-white/40 shadow-2xl rounded-3xl p-6 md:p-8 relative overflow-hidden"
            >
              {/* Dynamic Glare Overlay */}
              <motion.div 
                style={{ background: glareBackground, opacity: 0.6 }}
                className="absolute inset-0 z-20 pointer-events-none mix-blend-overlay"
              />
              
              {/* Glass Reflection Gradient (Static) */}
              <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-white/40 to-transparent pointer-events-none z-10" />

              {/* Mock Content */}
              <div className="space-y-6 relative z-10">
                <div className="flex items-center justify-between border-b border-slate-200/50 pb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-[#1F4FFF]/10 flex items-center justify-center text-[#1F4FFF]">
                      <Activity size={20} />
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-900">Live Poll #402</h3>
                      <p className="text-xs text-slate-500">245 Participants</p>
                    </div>
                  </div>
                  <div className="px-2 py-1 bg-[#22C55E]/10 text-[#22C55E] text-xs font-bold rounded uppercase tracking-wider">
                    Active
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="text-lg font-semibold text-slate-900 leading-snug">What is the future of Web3 UX?</h4>
                  {[
                    { label: "Invisible Wallets", pct: 65, color: "bg-[#1F4FFF]" },
                    { label: "Biometric Auth", pct: 25, color: "bg-slate-200" },
                    { label: "Hardware Keys", pct: 10, color: "bg-slate-200" }
                  ].map((item, i) => (
                    <div key={i} className="group cursor-pointer">
                      <div className="flex justify-between text-sm mb-1 font-medium text-slate-700">
                        <span>{item.label}</span>
                        <span>{item.pct}%</span>
                      </div>
                      <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: `${item.pct}%` }}
                          transition={{ duration: 1.5, delay: 0.8 + (i * 0.2) }}
                          className={`h-full rounded-full ${item.color}`} 
                        />
                      </div>
                    </div>
                  ))}
                </div>

                <div className="pt-4 flex items-center gap-2 text-xs text-slate-400">
                   <ShieldCheck size={14} />
                   <span>Verifiable on-chain</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ---------------- STATS SECTION ---------------- */}
      <section className="py-12 border-y border-slate-100 bg-slate-50/50">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-center">
             <div className="text-slate-400 font-bold uppercase tracking-widest text-sm text-center md:text-left">Trusted by</div>
             {['Ethereum Foundation', 'Polygon', 'Optimism'].map((name, i) => (
               <div key={i} className="text-slate-300 font-black text-xl md:text-2xl text-center grayscale hover:grayscale-0 hover:text-slate-800 transition-all cursor-default">
                 {name}
               </div>
             ))}
          </div>
        </div>
      </section>

      {/* ---------------- FEATURES SECTION ---------------- */}
      <section className="py-24 px-6 relative overflow-hidden">
        <div className="container mx-auto max-w-6xl">
          <div className="mb-20 max-w-2xl">
            <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">Built for the decentralized web.</h2>
            <p className="text-xl text-slate-500 leading-relaxed">
              Move beyond basic surveys. Tally brings cryptographic verifiability to audience engagement.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ y: -10 }}
                className="p-8 rounded-3xl border border-slate-100 bg-white hover:border-slate-200 hover:shadow-xl hover:shadow-slate-200/40 transition-all group"
              >
                <div className={`w-14 h-14 rounded-2xl ${feature.bg} ${feature.color} flex items-center justify-center mb-6 transition-transform group-hover:scale-110`}>
                  {feature.icon}
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-3">{feature.title}</h3>
                <p className="text-slate-500 leading-relaxed">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------- METRICS / CTA SECTION ---------------- */}
      <section className="py-24 px-6 bg-[#1F2937] text-white relative overflow-hidden">
        {/* Abstract shapes */}
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-[#1F4FFF] rounded-full blur-[120px] opacity-20 pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-[#22C55E] rounded-full blur-[100px] opacity-10 pointer-events-none" />

        <div className="container mx-auto max-w-5xl relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-20 border-b border-white/10 pb-12"
          >
            {stats.map((stat, i) => (
              <div key={i}>
                <div className="text-5xl md:text-6xl font-bold mb-2 tracking-tight">{stat.value}</div>
                <div className="text-slate-400 font-medium uppercase tracking-wider text-sm">{stat.label}</div>
              </div>
            ))}
          </motion.div>

          <h2 className="text-4xl md:text-5xl font-bold mb-8">Ready to start your session?</h2>
          <p className="text-xl text-slate-400 mb-10 max-w-2xl mx-auto">
            No signups, no credit cards. Just connect your wallet and engage your audience in seconds.
          </p>
          
          <button 
            onClick={onStart}
            className="px-10 py-5 bg-white text-slate-900 rounded-2xl font-bold text-lg hover:bg-blue-50 transition-colors inline-flex items-center gap-2"
          >
            Launch App <ArrowRight size={20} />
          </button>
        </div>
      </section>

      {/* ---------------- FOOTER ---------------- */}
      <footer className="py-12 px-6 border-t border-slate-100 bg-white">
        <div className="container mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2 text-slate-900 font-bold text-xl">
             <div className="w-8 h-8"><Logo className="w-full h-full" /></div>
             Tally
          </div>
          <div className="text-slate-400 text-sm">
            © 2024 Tally. Built for the decentralized future.
          </div>
          <div className="flex gap-6">
            {['Twitter', 'GitHub', 'Discord'].map(social => (
              <a key={social} href="#" className="text-slate-400 hover:text-[#1F4FFF] transition-colors font-medium text-sm">
                {social}
              </a>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
};