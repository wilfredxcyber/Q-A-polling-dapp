import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Copy, Plus, BarChart2, MessageSquare, ChevronRight, Check, Power, AlertTriangle } from 'lucide-react';

export const HostDashboard: React.FC = () => {
  const [sessionActive, setSessionActive] = useState(false);
  const [sessionName, setSessionName] = useState('');
  const [copied, setCopied] = useState(false);
  const [qaEnabled, setQaEnabled] = useState(true);
  const [showEndConfirmation, setShowEndConfirmation] = useState(false);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (sessionName.trim()) {
      setSessionActive(true);
    }
  };

  const handleEndSession = () => {
    setSessionActive(false);
    setShowEndConfirmation(false);
    setSessionName('');
  };

  const copyLink = () => {
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-white pt-24 pb-24 px-6 max-w-5xl mx-auto relative">
      <AnimatePresence mode='wait'>
        {!sessionActive ? (
          /* CREATE SESSION STATE */
          <motion.div
            key="create"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="max-w-xl mx-auto"
          >
            <h2 className="text-4xl font-bold text-slate-900 mb-2">Create Session</h2>
            <p className="text-slate-500 mb-10 text-lg">Set up a new space for your audience.</p>

            <form onSubmit={handleCreate} className="space-y-8">
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-700 uppercase tracking-wider">Session Name</label>
                <input 
                  type="text" 
                  value={sessionName}
                  onChange={(e) => setSessionName(e.target.value)}
                  placeholder="e.g. Town Hall Q3"
                  className="w-full text-3xl font-bold border-b-2 border-slate-200 py-4 focus:outline-none focus:border-[#1F4FFF] placeholder:text-slate-300 transition-colors bg-transparent"
                  autoFocus
                />
              </div>

              <div className="flex justify-end">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  type="submit"
                  disabled={!sessionName}
                  className={`px-8 py-4 rounded-xl font-bold text-lg flex items-center gap-3 shadow-lg transition-all ${
                    sessionName 
                      ? 'bg-[#1F4FFF] text-white shadow-blue-500/30' 
                      : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  Create Session <ChevronRight size={20} />
                </motion.button>
              </div>
            </form>
          </motion.div>
        ) : (
          /* DASHBOARD STATE */
          <motion.div
            key="dashboard"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-12"
          >
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-8 border-b border-slate-100">
              <div className="flex-1">
                <h1 className="text-3xl font-bold text-slate-900">{sessionName}</h1>
                <div className="flex items-center gap-2 mt-2">
                  <span className="w-2 h-2 bg-[#22C55E] rounded-full animate-pulse"/>
                  <span className="text-sm text-[#22C55E] font-medium">Live Now</span>
                  <span className="text-slate-300 mx-2">|</span>
                  <span className="text-sm text-slate-500">0 Participants</span>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                {/* Link Card */}
                <div 
                  onClick={copyLink}
                  className="bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 flex items-center gap-4 cursor-pointer hover:bg-slate-100 transition-colors group flex-1 sm:flex-initial"
                >
                  <div className="text-left">
                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Session Link</p>
                    <p className="text-slate-900 font-mono text-sm">tally.app/j/8f92-a2</p>
                  </div>
                  <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-400 group-hover:text-[#1F4FFF] transition-colors ml-2">
                    {copied ? <Check size={16} className="text-[#22C55E]" /> : <Copy size={16} />}
                  </div>
                </div>

                {/* End Session Button */}
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setShowEndConfirmation(true)}
                  className="bg-red-50 hover:bg-red-100 text-red-600 border border-red-100 rounded-xl px-4 py-3 font-bold flex items-center justify-center gap-2 transition-colors"
                >
                  <Power size={20} />
                  <span className="hidden sm:inline">End</span>
                </motion.button>
              </div>
            </div>

            {/* Controls Grid */}
            <div className="grid md:grid-cols-2 gap-8">
              {/* Polls Section */}
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 }}
                className="p-8 rounded-3xl bg-white border border-slate-100 shadow-xl shadow-slate-200/50 relative overflow-hidden group hover:border-blue-100 transition-colors"
              >
                <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
                  <BarChart2 size={120} />
                </div>
                <div className="relative z-10">
                  <div className="w-12 h-12 rounded-2xl bg-[#1F4FFF]/10 text-[#1F4FFF] flex items-center justify-center mb-6">
                    <BarChart2 size={24} />
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900 mb-2">Live Polls</h3>
                  <p className="text-slate-500 mb-8">Create multiple choice questions to get instant feedback.</p>
                  
                  <button className="w-full py-4 border-2 border-dashed border-slate-200 rounded-xl text-slate-400 font-semibold hover:border-[#1F4FFF] hover:text-[#1F4FFF] hover:bg-[#1F4FFF]/5 transition-all flex items-center justify-center gap-2">
                    <Plus size={20} /> Create New Poll
                  </button>
                </div>
              </motion.div>

              {/* Q&A Section */}
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 }}
                className="p-8 rounded-3xl bg-white border border-slate-100 shadow-xl shadow-slate-200/50 relative overflow-hidden group hover:border-green-100 transition-colors"
              >
                <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
                  <MessageSquare size={120} />
                </div>
                <div className="relative z-10">
                  <div className="w-12 h-12 rounded-2xl bg-[#22C55E]/10 text-[#22C55E] flex items-center justify-center mb-6">
                    <MessageSquare size={24} />
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900 mb-2">Q&A</h3>
                  <p className="text-slate-500 mb-8">Manage incoming questions from your audience.</p>
                  
                  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl">
                    <span className="font-semibold text-slate-700">Q&A Status</span>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input 
                        type="checkbox" 
                        className="sr-only peer" 
                        checked={qaEnabled}
                        onChange={() => setQaEnabled(!qaEnabled)}
                      />
                      <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#22C55E]"></div>
                    </label>
                  </div>
                  <p className={`text-xs mt-2 font-medium text-right ${qaEnabled ? 'text-[#22C55E]' : 'text-slate-400'}`}>
                      {qaEnabled ? 'Submissions Open' : 'Submissions Paused'}
                   </p>
                </div>
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Confirmation Modal */}
      <AnimatePresence>
        {showEndConfirmation && (
            <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm z-50 flex items-center justify-center p-6"
                onClick={() => setShowEndConfirmation(false)}
            >
                <motion.div 
                    initial={{ scale: 0.95, opacity: 0, y: 10 }}
                    animate={{ scale: 1, opacity: 1, y: 0 }}
                    exit={{ scale: 0.95, opacity: 0, y: 10 }}
                    onClick={(e) => e.stopPropagation()}
                    className="bg-white rounded-3xl shadow-2xl p-8 max-w-sm w-full border border-slate-100"
                >
                    <div className="w-12 h-12 bg-red-50 text-red-500 rounded-full flex items-center justify-center mb-4 mx-auto">
                        <AlertTriangle size={24} />
                    </div>
                    <div className="text-center mb-8">
                        <h3 className="text-xl font-bold text-slate-900 mb-2">End Session?</h3>
                        <p className="text-slate-500 text-sm leading-relaxed">
                            This will disconnect all participants and archive the current results. This action cannot be undone.
                        </p>
                    </div>
                    <div className="flex gap-3">
                        <button 
                            onClick={() => setShowEndConfirmation(false)}
                            className="flex-1 py-3 px-4 rounded-xl font-bold text-slate-600 bg-slate-50 hover:bg-slate-100 transition-colors"
                        >
                            Cancel
                        </button>
                        <button 
                            onClick={handleEndSession}
                            className="flex-1 py-3 px-4 rounded-xl font-bold text-white bg-red-500 hover:bg-red-600 shadow-lg shadow-red-500/30 transition-all"
                        >
                            End Session
                        </button>
                    </div>
                </motion.div>
            </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};