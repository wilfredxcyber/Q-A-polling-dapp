import React from 'react';

export const Logo: React.FC<{ className?: string }> = ({ className = "w-12 h-12" }) => (
  <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    <defs>
      <linearGradient id="logoGradient" x1="10%" y1="0%" x2="90%" y2="100%">
        <stop offset="0%" stopColor="#3b82f6" /> {/* Blue-500 equivalent */}
        <stop offset="100%" stopColor="#22C55E" /> {/* Green-500 equivalent */}
      </linearGradient>
      <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
        <feGaussianBlur stdDeviation="3" result="coloredBlur" />
        <feMerge>
            <feMergeNode in="coloredBlur" />
            <feMergeNode in="SourceGraphic" />
        </feMerge>
      </filter>
    </defs>
    
    {/* Main Body */}
    <rect x="25" y="10" width="50" height="80" rx="8" fill="url(#logoGradient)" />
    
    {/* Diagonal Slash - simulating the cut */}
    <path 
      d="M 60 25 L 40 75" 
      stroke="white" 
      strokeWidth="3" 
      strokeLinecap="round"
      style={{ filter: 'drop-shadow(0 0 2px rgba(255,255,255,0.8))' }}
    />
  </svg>
);