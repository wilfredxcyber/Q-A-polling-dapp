import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Loader2, ArrowRight } from 'lucide-react';

export const JoinScreen: React.FC = () => {
  const [joined, setJoined] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleJoin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate network request
    setTimeout(() => {
      setLoading(false);
      setJoined(true);
    }, 1500);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        {!joined ? (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl shadow-2xl shadow-slate-200/50 p-8 md:p-12 border border-slate-100"
          >
            <div className="text-center mb-10">
              <h2 className="text-3xl font-bold text-slate-900 mb-2">Join Session</h2>
              <p className="text-slate-500">Enter the code provided by your host.</p>
            </div>

            <form onSubmit={handleJoin} className="space-y-6">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2 ml-1">Session Code</label>
                <input 
                  type="text" 
                  placeholder="e.g. 402-991"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-xl font-mono font-medium focus:outline-none focus:ring-2 focus:ring-[#1F4FFF]/20 focus:border-[#1F4FFF] transition-all text-slate-900"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2 ml-1">Your Nickname (Optional)</label>
                <input 
                  type="text" 
                  placeholder="Anonymous"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 text-lg focus:outline-none focus:ring-2 focus:ring-[#1F4FFF]/20 focus:border-[#1F4FFF] transition-all text-slate-900"
                />
              </div>

              <motion.button 
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                disabled={loading}
                className="w-full bg-[#1F4FFF] text-white font-bold text-lg py-4 rounded-xl shadow-lg shadow-blue-500/20 hover:shadow-blue-500/40 transition-all flex items-center justify-center gap-2"
              >
                {loading ? <Loader2 className="animate-spin" /> : <>Join Session <ArrowRight size={20} /></>}
              </motion.button>
            </form>
          </motion.div>
        ) : (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <div className="w-24 h-24 bg-[#22C55E] rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl shadow-green-500/30">
              <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"></path>
              </svg>
            </div>
            <h2 className="text-3xl font-bold text-slate-900 mb-4">You're in!</h2>
            <p className="text-slate-500 text-lg">Waiting for the host to start the first activity...</p>
            
            <div className="mt-12 flex justify-center gap-2">
              <span className="w-2 h-2 bg-slate-300 rounded-full animate-bounce" style={{ animationDelay: '0s' }} />
              <span className="w-2 h-2 bg-slate-300 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
              <span className="w-2 h-2 bg-slate-300 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }} />
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};