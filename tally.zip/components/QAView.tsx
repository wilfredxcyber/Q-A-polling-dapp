import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowUp, Send, MessageSquare, Crown } from 'lucide-react';

interface Question {
  id: string;
  text: string;
  votes: number;
  isUser: boolean;
  timestamp: number;
}

const INITIAL_QUESTIONS: Question[] = [
  { id: '1', text: "How does this scale to 10,000 users concurrently?", votes: 42, isUser: false, timestamp: 1 },
  { id: '2', text: "Can we integrate this with existing DAO governance tools?", votes: 28, isUser: false, timestamp: 2 },
  { id: '3', text: "What is the gas cost for voting?", votes: 15, isUser: false, timestamp: 3 },
  { id: '4', text: "Is the code open source?", votes: 8, isUser: false, timestamp: 4 },
];

export const QAView: React.FC = () => {
  const [questions, setQuestions] = useState<Question[]>(INITIAL_QUESTIONS);
  const [inputText, setInputText] = useState('');
  const [userVotedIds, setUserVotedIds] = useState<Set<string>>(new Set());

  // Sort questions: Descending votes
  const sortedQuestions = [...questions].sort((a, b) => b.votes - a.votes);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const newQuestion: Question = {
      id: Date.now().toString(),
      text: inputText,
      votes: 0,
      isUser: true,
      timestamp: Date.now()
    };

    setQuestions(prev => [...prev, newQuestion]);
    setInputText('');
  };

  const handleVote = (id: string) => {
    if (userVotedIds.has(id)) {
        setQuestions(prev => prev.map(q => q.id === id ? { ...q, votes: q.votes - 1 } : q));
        setUserVotedIds(prev => {
            const next = new Set(prev);
            next.delete(id);
            return next;
        });
    } else {
        setQuestions(prev => prev.map(q => q.id === id ? { ...q, votes: q.votes + 1 } : q));
        setUserVotedIds(prev => new Set(prev).add(id));
    }
  };

  return (
    <div className="h-full bg-white flex justify-center">
      <div className="w-full max-w-3xl flex flex-col h-full relative">
        
        {/* Header - Sticky */}
        <div className="flex-none px-6 pt-6 pb-4 bg-white/95 backdrop-blur-sm z-10 sticky top-0">
          <div className="flex items-end justify-between">
              <div>
                  <h2 className="text-3xl md:text-4xl font-bold text-slate-900">Q&A</h2>
                  <p className="text-slate-500 mt-1 text-sm md:text-base">Ask questions and upvote the best ones.</p>
              </div>
              <div className="flex items-center gap-2 text-xs md:text-sm font-semibold text-[#22C55E] bg-[#22C55E]/10 px-3 py-1 rounded-full">
                  <span className="w-2 h-2 rounded-full bg-[#22C55E] animate-pulse" />
                  Live
              </div>
          </div>
        </div>

        {/* Question List (Scrollable) */}
        <div className="flex-1 overflow-y-auto px-6 pb-4 space-y-4 scroll-smooth">
          <AnimatePresence initial={false}>
            {sortedQuestions.map((q, index) => (
              <motion.div
                layout
                key={q.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
                className={`p-5 rounded-2xl border transition-colors group relative ${
                  index === 0 
                    ? 'bg-gradient-to-br from-white to-blue-50 border-blue-200 shadow-xl shadow-blue-500/10 z-10' 
                    : 'bg-white border-slate-100 hover:border-slate-200'
                }`}
              >
                {index === 0 && (
                    <div className="absolute -top-2.5 left-6 bg-[#1F4FFF] text-white text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-full flex items-center gap-1 shadow-md">
                        <Crown size={10} /> Top
                    </div>
                )}

                <div className="flex gap-4 md:gap-6">
                  {/* Vote Button */}
                  <div className="flex flex-col items-center gap-1 pt-1">
                    <button
                      onClick={() => handleVote(q.id)}
                      className={`w-10 h-10 md:w-12 md:h-12 rounded-xl flex items-center justify-center transition-all ${
                        userVotedIds.has(q.id)
                          ? 'bg-[#1F4FFF] text-white shadow-lg shadow-blue-500/30 scale-105'
                          : 'bg-slate-50 text-slate-400 hover:bg-slate-100 hover:text-[#1F4FFF]'
                      }`}
                    >
                      <ArrowUp size={20} className={userVotedIds.has(q.id) ? '' : 'stroke-[3px]'} />
                    </button>
                    <span className={`text-xs md:text-sm font-bold ${userVotedIds.has(q.id) ? 'text-[#1F4FFF]' : 'text-slate-400'}`}>
                        {q.votes}
                    </span>
                  </div>

                  {/* Text */}
                  <div className="flex-1 pt-0.5">
                    <p className={`text-base md:text-lg font-medium leading-relaxed ${index === 0 ? 'text-slate-900' : 'text-slate-700'}`}>
                        {q.text}
                    </p>
                    {q.isUser && (
                        <span className="text-[10px] md:text-xs text-slate-400 font-semibold mt-2 inline-block bg-slate-50 px-2 py-0.5 rounded">You</span>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Input Area (Fixed to bottom of component) */}
        {/* We use sticky or fixed here but positioned above the global nav padding (pb-24 approx) */}
        <div className="flex-none p-4 md:p-6 bg-white border-t border-slate-100/80 backdrop-blur-lg z-20">
            <form onSubmit={handleSubmit} className="relative">
                <input
                    type="text"
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder="Ask a question..."
                    className="w-full bg-slate-50 border border-slate-200 text-slate-900 text-base md:text-lg rounded-2xl pl-5 pr-14 py-3 md:py-4 focus:outline-none focus:ring-2 focus:ring-[#1F4FFF]/20 focus:border-[#1F4FFF] transition-all placeholder:text-slate-400 shadow-sm"
                />
                <button 
                    type="submit"
                    disabled={!inputText.trim()}
                    className="absolute right-2 top-2 bottom-2 aspect-square bg-[#1F4FFF] hover:bg-blue-600 disabled:bg-slate-200 disabled:cursor-not-allowed text-white rounded-xl transition-colors shadow-lg shadow-blue-500/20 disabled:shadow-none flex items-center justify-center"
                >
                    <Send size={18} />
                </button>
            </form>
        </div>

      </div>
    </div>
  );
};