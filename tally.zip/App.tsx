import React, { useState } from 'react';
import { LandingPage } from './components/LandingPage';
import { HostDashboard } from './components/HostDashboard';
import { JoinScreen } from './components/JoinScreen';
import { PollView } from './components/PollView';
import { QAView } from './components/QAView';
import { WalletConnect } from './components/WalletConnect';
import { Logo } from './components/Logo';
import { LayoutGrid, Users, BarChart2, MessageSquare, Home } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';

enum View {
  LANDING = 'LANDING',
  WALLET = 'WALLET',
  HOST = 'HOST',
  JOIN = 'JOIN',
  POLL = 'POLL',
  QA = 'QA'
}

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>(View.LANDING);
  const [isConnected, setIsConnected] = useState(false);

  const handleWalletConnect = () => {
    setIsConnected(true);
    setCurrentView(View.HOST);
  };

  // Render the specific flow based on state
  const renderView = () => {
    switch (currentView) {
      case View.LANDING:
        return <LandingPage onStart={() => setCurrentView(View.WALLET)} />;
      case View.WALLET:
        return <WalletConnect onConnect={handleWalletConnect} />;
      case View.HOST:
        return <HostDashboard />;
      case View.JOIN:
        return <JoinScreen />;
      case View.POLL:
        return <PollView />;
      case View.QA:
        return <QAView />;
      default:
        return <LandingPage onStart={() => setCurrentView(View.WALLET)} />;
    }
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 relative overflow-hidden flex flex-col">
      
      {/* Mobile/Desktop Header */}
      <header className="fixed top-0 left-0 right-0 h-16 bg-white/80 backdrop-blur-md z-40 border-b border-slate-100 px-6 flex items-center justify-between">
        <div 
          className="flex items-center gap-3 cursor-pointer"
          onClick={() => {
            if (isConnected) setCurrentView(View.HOST);
            else setCurrentView(View.LANDING);
          }}
        >
          <div className="shadow-lg shadow-blue-500/20 rounded-lg">
            <Logo className="w-8 h-8" />
          </div>
          <span className="font-bold text-lg tracking-tight font-['Space_Grotesk']">Tally</span>
        </div>
        
        {isConnected && (
            <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-full">
                <div className="w-2 h-2 rounded-full bg-[#22C55E]" />
                <span className="text-xs font-mono font-medium text-slate-600">0x84...92A</span>
            </div>
        )}
      </header>

      {/* Main Content Area */}
      {/* Adjusted padding: pb-24 ensures content isn't hidden behind mobile nav */}
      <main className="w-full flex-1 pt-16 pb-24 md:pb-6 overflow-y-auto overflow-x-hidden">
        {renderView()}
      </main>

      {/* Navigation - Only visible after connection */}
      <AnimatePresence>
        {isConnected && (
          <motion.nav 
            initial={{ y: 100 }}
            animate={{ y: 0 }}
            exit={{ y: 100 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="fixed bottom-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-xl border-t border-slate-200 md:bg-white/80 md:border md:shadow-2xl md:rounded-full md:bottom-6 md:left-1/2 md:right-auto md:w-auto md:transform md:-translate-x-1/2"
            style={{ paddingBottom: 'env(safe-area-inset-bottom, 20px)' }}
          >
            <div className="px-6 py-3 md:py-3 w-full md:w-auto">
                {/* Mobile: Grid for even spacing. Desktop: Flex for pill shape. */}
                <div className="grid grid-cols-4 gap-1 md:flex md:items-center md:gap-6 w-full md:w-auto justify-items-center">
                    <NavButton 
                    active={currentView === View.HOST} 
                    onClick={() => setCurrentView(View.HOST)} 
                    icon={<LayoutGrid size={24} />} 
                    label="Host" 
                    />
                    <NavButton 
                    active={currentView === View.JOIN} 
                    onClick={() => setCurrentView(View.JOIN)} 
                    icon={<Users size={24} />} 
                    label="Join" 
                    />
                    {/* Divider - Hidden on Mobile */}
                    <div className="hidden md:block w-px h-6 bg-slate-200 mx-2" />
                    <NavButton 
                    active={currentView === View.POLL} 
                    onClick={() => setCurrentView(View.POLL)} 
                    icon={<BarChart2 size={24} />} 
                    label="Poll" 
                    />
                    <NavButton 
                    active={currentView === View.QA} 
                    onClick={() => setCurrentView(View.QA)} 
                    icon={<MessageSquare size={24} />} 
                    label="Q&A" 
                    />
                </div>
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </div>
  );
};

const NavButton: React.FC<{ 
  active: boolean; 
  onClick: () => void; 
  icon: React.ReactNode; 
  label: string 
}> = ({ active, onClick, icon, label }) => (
  <button 
    onClick={onClick}
    className={`flex flex-col items-center gap-1 transition-colors duration-300 group w-full md:w-auto md:min-w-[60px] ${
      active ? 'text-[#1F4FFF]' : 'text-slate-400 hover:text-slate-600'
    }`}
  >
    <div className={`transition-transform duration-300 p-1.5 rounded-xl ${
      active ? 'bg-blue-50 scale-100 md:scale-110' : 'group-hover:scale-110'
    }`}>
      {icon}
    </div>
    <span className="text-[10px] font-bold tracking-wide uppercase">{label}</span>
  </button>
);

export default App;